# MetroCheck — SIH26034 Software Package

This package combines the MetroCheck React frontend with a runnable Node/Express MVP backend and the Java compliance reference supplied for the project.

## What is included
- Public landing page
- Login + **Sign Up** flow
- Protected Dashboard, New Scan, Processing, Result, History and Profile pages
- Camera/file upload UI
- JWT authentication with bcrypt password hashing
- Image upload + Tesseract OCR
- Deterministic extraction for the ProductData structure you supplied
- Compliance checks matching the supplied Java ComplianceEngine for rules 6(1)(a) through 6(1)(i)
- Scan history and dashboard statistics
- PDF compliance report
- Java reference implementation of ComplianceEngine/Violation

## Run backend
```bash
cd backend
npm install
npm start
```
Backend: http://localhost:3000

## Run frontend
```bash
cd frontend
npm install
npm run dev
```
Frontend normally opens at the Vite URL shown in the terminal.

The frontend defaults to `http://localhost:3000/api/v1`. To change it, copy `frontend/.env.example` to `frontend/.env` and set `VITE_API_URL`.

## Important scope note
The complete authentication/API wrapper is included so the software is runnable. The actual Java code you supplied did not contain the authentication controller, database layer, OCR implementation or HTTP API, so those pieces are implemented as the MVP integration layer rather than claimed to be your original backend. The compliance checks themselves mirror the supplied Java checks.

The supplied Java engine currently checks 6(1)(a)-(i); it does not automatically check 6(1)(j). The frontend therefore does not invent a 6(1)(j) result.
