import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
const dataDir=path.resolve('data'); const file=path.join(dataDir,'db.json');
if(!fs.existsSync(dataDir)) fs.mkdirSync(dataDir,{recursive:true});
if(!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify({users:[],scans:[]},null,2));
export function readDb(){return JSON.parse(fs.readFileSync(file,'utf8'));}
export function writeDb(db){fs.writeFileSync(file,JSON.stringify(db,null,2));}
export function id(){return crypto.randomUUID();}
