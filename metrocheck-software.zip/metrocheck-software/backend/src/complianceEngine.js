export class ComplianceEngine {
  check(product){
    const violations=[]; const data=product.extracted_text || {}; const empty=v=>v==null || String(v).trim()==='';
    if(empty(data.product_name)) violations.push(v('6(1)(a)','Name/Common Name of Commodity','HIGH','Product/commodity name was not detected.','Verify that the common or generic name of the commodity is declared.'));
    if(!data.manufacturer || empty(data.manufacturer.name)||empty(data.manufacturer.address)) violations.push(v('6(1)(b)','Manufacturer/Packer/Importer Details','HIGH','Manufacturer name and/or address was not detected.','Verify that the required name and address declaration is present.'));
    if(!data.net_quantity || Number(data.net_quantity.value)<=0 || empty(data.net_quantity.unit)) violations.push(v('6(1)(c)','Net Quantity','HIGH','Valid net quantity was not detected.','Verify that net quantity is declared with the appropriate unit.'));
    if(!(Number(data.mrp_value)>0)) violations.push(v('6(1)(d)','Maximum Retail Price','HIGH','MRP value was not detected in the extracted data.','Verify that MRP inclusive of all taxes is declared on the package.'));
    if(empty(data.ingredients)) violations.push(v('6(1)(e)','List of Ingredients','MEDIUM','Ingredients list was not detected.','Verify whether an ingredients declaration is required and present.'));
    if(!data.nutrition_information) violations.push(v('6(1)(f)','Nutritional Information','MEDIUM','Nutritional information was not detected.','Verify whether nutritional information is applicable and present.'));
    if(empty(data.manufacturing_date)) violations.push(v('6(1)(g)','Manufacturing Date','HIGH','Manufacturing date was not detected.','Verify that manufacturing/packing date in the required format is declared.'));
    if(empty(data.expiry_date)) violations.push(v('6(1)(h)','Best Before / Use By Date','HIGH','Expiry/best-before/use-by information was not detected.','Verify that the applicable date declaration is present.'));
    if(!data.contact || (empty(data.contact.email)&&empty(data.contact.phone))) violations.push(v('6(1)(i)','Customer Complaint Contact','MEDIUM','No customer complaint contact information was detected.','Verify that the required customer complaint/contact declaration is present.'));
    return violations;
  }
}
function v(ruleId,title,severity,evidence,recommendation){return {ruleId,title,severity,evidence,recommendation};}
