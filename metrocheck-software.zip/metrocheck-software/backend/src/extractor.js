export function extractProduct(text, originalName='Uploaded product'){
  const t=text.replace(/\r/g,' '); const pick=(re)=>{const m=t.match(re); return m?m[1].trim():''};
  const productName=pick(/(?:name|product|commodity)\s*[:\-]?\s*([A-Za-z][A-Za-z0-9 &(),.-]{2,})/i);
  const manufacturerName=pick(/manufacturer(?:\/packer\/importer)?\s*[:\-]?\s*([^\n]{2,})/i);
  const address=pick(/address\s*[:\-]?\s*([^\n]{5,})/i);
  const qty=t.match(/(?:net\s*(?:qty|quantity)?|weight|wt\.?)\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*(mg|g|kg|ml|l|units?)/i);
  const mrp=t.match(/mrp[^0-9₹]*₹?\s*(\d+(?:\.\d+)?)/i);
  const mfg=pick(/(?:mfg|manufactur(?:ed|ing))[^0-9]*(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4}|\d{1,2}[\/-]\d{4})/i);
  const exp=pick(/(?:best\s*before|use\s*by|expiry|exp)[^0-9]*(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4}|\d{1,2}[\/-]\d{4})/i);
  const ingredients=pick(/ingredients?\s*[:\-]?\s*([^\n]{3,})/i);
  const email=pick(/([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})/i);
  const phone=pick(/(?:phone|helpline|contact)\s*[:\-]?\s*(\+?\d[\d -]{7,})/i);
  const nutrition=/nutrition|nutritional information|energy\s*[:\-]?\s*\d+/i.test(t)?{}:null;
  return {source:{type:'image',product:productName||originalName},extracted_text:{brand:'',product_name:productName,ingredients,nutrition_information:nutrition,manufacturer:{name:manufacturerName,address},contact:{email,phone,website_text:''},claims_and_storage:[],net_quantity:qty?{value:Number(qty[1]),unit:qty[2]}:null,fssai:{license_number:''},barcode:'',pack_declaration_text:'',mrp_value:mrp?Number(mrp[1]):null,manufacturing_date:mfg,expiry_date:exp,batch_number:'',other_visible_text:[]}};
}
