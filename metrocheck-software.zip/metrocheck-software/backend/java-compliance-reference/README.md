# Java compliance reference

This folder preserves the compliance-layer logic supplied for MetroCheck. The runnable web MVP uses a JavaScript adapter with the same checks so the React frontend can communicate through the Node/Express API described in the project tech-stack document.
