import { ArrowRight, ScanLine, ShieldCheck, FileCheck2 } from "lucide-react";
import { useNavigate } from "react-router-dom";

export function Home() {
  const navigate = useNavigate();

  return (
    <div className="landing">
      <header className="landing-nav">
        <button className="brand dark" onClick={() => navigate("/")}>
          <span className="brand-mark"><ShieldCheck size={20} /></span>
          <span><strong>MetroCheck</strong><small>LEGAL METROLOGY AI</small></span>
        </button>
        <nav className="landing-links">
          <a href="#home">Home</a>
          <a href="#how">How It Works</a>
          <a href="#about">About</a>
        </nav>
        <div className="landing-actions">
          <button className="btn secondary" onClick={() => navigate("/login")}>Login</button>
          <button className="btn secondary" onClick={() => navigate("/signup")}>Sign Up</button>
          <button className="btn dark-btn" onClick={() => navigate("/login")}>Get Started</button>
        </div>
      </header>

      <section className="hero" id="home">
        <div className="hero-badge">● LEGAL METROLOGY (PACKAGED COMMODITIES) RULES 2024</div>
        <h1>Automate Legal Metrology Compliance for<br />Packaged Goods</h1>
        <p>Instantly scan packaging artworks and labels to verify mandatory declarations, font size heights, MRP/USP rules, and statutory compliance in seconds.</p>
        <button className="btn primary hero-btn" onClick={() => navigate("/login")}>
          <ScanLine size={18} /> Scan a Product <ArrowRight size={18} />
        </button>
      </section>

      <section className="landing-cards" id="how">
        <div><FileCheck2 size={28}/><h3>Upload or Capture</h3><p>Use your camera or upload a packaging image.</p></div>
        <div><ScanLine size={28}/><h3>Automatic Analysis</h3><p>OCR and statutory rules inspect the label.</p></div>
        <div><ShieldCheck size={28}/><h3>Clear Verdict</h3><p>See passed checks, violations and corrective action.</p></div>
      </section>
    </div>
  );
}
